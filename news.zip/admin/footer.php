<!-- Footer -->
<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2021 Daily Global News | Powered by DGE</span>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>
</html>
