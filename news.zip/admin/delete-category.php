<?php
include 'dbconnect.php';

$category_id=$_GET['id'];

$sql="DELETE FROM category WHERE category_id={$category_id}";

if(mysqli_query($conn,$sql)){
    header("location: category.php");
       
}
else{
    echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Warning!</strong>Cannot delete user record.
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
  </div>';
}
mysqli_close($conn);
?>