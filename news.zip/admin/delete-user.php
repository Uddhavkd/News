<?php
include 'dbconnect.php';

$user_id=$_GET['id'];

$sql="DELETE FROM user WHERE user_id={$user_id}";

if(mysqli_query($conn,$sql)){
    header("location: users.php");
       
}
else{
    echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Warning!</strong>Cannot delete user record.
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
  </div>';
}
mysqli_close($conn);
?>