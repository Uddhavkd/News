<?php 

include 'dbconnect.php';

if(empty($_FILES['new-image']['name'])){

    $file_name= $_POST['old_image'];
}
else{
    $errors=array();

    $file_name=$_FILES['new-image']['name'];
    $file_size=$_FILES['new-image']['size'];
    $file_tmp=$_FILES['new-image']['tmp_name'];
    $file_type=$_FILES['new-image']['type'];
    $file_ext= end(explode('.',$file_name));
    $extensions = array("jpeg","jpg","png","PNG");

    if(in_array($file_ext,$extensions)==false){
        $errors[]="This file extension is not Valid. Please Use a JPEG, JPG or PNG Format";
    }

    if($file_size > 2097152){
        $errors[]="File should be less than 2 MB";  
      }

    if(empty($errors)==true){
        move_uploaded_file($file_tmp,"upload/".$file_name);
    }
    else{
        print_r($errors);
        die();
    }
}

$sql="UPDATE post SET title='{$_POST["post_title"]}',description='{$_POST["postdesc"]}',category={$_POST["category"]},post_image='{$file_name}'
        WHERE post_id={$_POST["post_id"]}";

if(mysqli_query($conn,$sql)){
    header("location: post.php");}
else{
    echo"Query Fail";
}
?>