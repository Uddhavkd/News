<?php

$showAlert=false;
$showError=false;
if($_SERVER["REQUEST_METHOD"]=="POST"){
    include 'config.php';
	$fname=$_POST["fname"];
	$lname=$_POST["lname"];
    $email=$_POST["email"];
    $mobile=$_POST["mobile"];
    $msg=$_POST["msg"];
    //exists=false;

      if(($fname == true  && $lname == true  && $email == true  && $msg == true)){
          $sql="INSERT INTO `feedback` ( `firstname`, `lastname`, `email`, `feedback`, `mobile`) 
          VALUES ( '$fname', '$lname','$email', '$msg', '$mobile')";
          $result= mysqli_query($conn, $sql);
          if($result){
            $showAlert=true;
            
		 }}
		 
		 
		 if(($fname == false  || $lname == false  || $email == false  || $msg == false)){
			  $showError=true;
			  
		   }
}

?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<?php include 'header.php'; ?>
		
		
	<!-- Feedback + Reach Us -->
		<div class="contact-content"><br>
		
			<span class="conhead"><h1><b>Get in touch<b></h1>
			<p>Want to get in touch? We'd love to hear from you. Here's how you can reach us...</p>
			</span>
			<br> 

		<!-- Feedback form -->
			<div class="contact-box">
				<div class="contact-top" style="background-color:black;"><br>

<?php 
if($showAlert){
    echo'<strong>Success!</strong> Your feedback has been submitted.';
}

if($showError){
    echo'<strong>Error!</strong> Enter All details Correctly';
}
?>


					<h1 style="font-size:50px;"><b>FEEDBACK</b></h1>
					<form class="ct" style="background-color:#dd2d2d;" action="/news/contact.php" method="post">
						<div class="fd">
						<div class="i1">
						<div class="input-feed col-xs-5 col-xs-offset-1">
						<label style="color:white;">First Name</label>
						<input style="background-color:#dd2d2d;" type="text" placeholder="" id="fname" name="fname">
						</div>
						
						<div class="input-feed col-xs-5 col-xs-offset-1">
						<label style="color:white;">Last Name</label>
						<input style="background-color:#dd2d2d;" type="text" placeholder="" id="lname" name="lname">
						</div>
						</div>
						
						<br>
						<br><br><br>
						
						<div class="i2">
						<div class="input-feed col-xs-5 col-xs-offset-1">
						<label style="color:white;">Mobile No.</label>
						<input style="background-color:#dd2d2d;" type="text" placeholder="" id="mobile" name="mobile">
						</div>
						
						<div class="input-feed col-xs-5 col-xs-offset-1">
						<label style="color:white;">Email - Id</label>
						<input style="background-color:#dd2d2d;" type="email" placeholder="" id="email" name="email">
						
						
						</div>
						</div>
						
						<br>
						<br>
						<label style="color:white;">Your Message</label><br>						
						<textarea  style="background-color:#dd2d2d;" id="txtar"rows="5" cols="80" placeholder="Type Your message here...." id="msg" name="msg"></textarea>
						
						<br>
						<br>
						<div>
						<input style="background-color:black;" type="submit" value="Send" color="black" id="conbtn" ><br><br>
						</div>
						</div>

					</form>
				</div>

				<br>

		<!-- Reach Us -->
				<div  class="contact-bottom" style="border:3px solid black ;">
					<div style="background-color:black;" class="">
					<h1><b>REACH US</b></h1>
					<div  style="background-color:#dd2d2d;" class="reach-icons">
						<span class="glyphicon glyphicon-envelope"></span>
						<p style="color:white;">      dailyglobal@gmail.com  </p>
						<span class="glyphicon glyphicon-phone-alt"></span>
						<p style="color:white;">  022 25648813</p>
						<span class="glyphicon glyphicon-map-marker"></span>
						<p style="color:white;"> DAILY GLOBAL <br>#111 Ground Floor Ace Residance<br> Sliver City Road, <br> Mumbai 400003 </p>
					</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>	

	<?php include 'footer.php'; ?>