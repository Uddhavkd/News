

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <title>News</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <link rel="stylesheet" href="css/style.css"> 
    <link rel="stylesheet" href="css/contact.css">
</head>
<body>
<!-- HEADER -->
<div id="header">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <!-- LOGO -->
            <div class=" col-md-offset-4 col-md-4">
                <a href="index.php" id="logo"><img src="images/DAILY GLOBAL.png"></a>
            </div>
            <!-- /LOGO -->
        </div>
    </div>
</div>
<!-- /HEADER -->
<!-- Menu Bar -->
<div id="menu-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <?php
                include 'config.php';

                if(isset($_GET['cid'])){
                $cat_id=$_GET['cid'];
                }

                $sql="SELECT * FROM category WHERE post > 0"; 
                $result=mysqli_query($conn,$sql) or die("Query Failed : category");
                if(mysqli_num_rows($result) > 0){
                    $active="";
            ?>
                <ul class='menu'>
                <li><a  href='index.php'>Home</a></li>
                   <?php 
                    while($row = mysqli_fetch_assoc($result)) { 
                    if(isset($_GET['cid'])){
                        if($row['category_id']==$cat_id){
                            $active="active";
                        }
                        else{
                            $active="";
                        }
                    }
                    echo "<li><a class='{$active}' href='category.php?cid={$row['category_id']}'>{$row['category_name']}</a></li>";
                     } ?>
                     <li><a  href='contact.php'>Contact</a></li>
                </ul>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<!-- /Menu Bar -->
